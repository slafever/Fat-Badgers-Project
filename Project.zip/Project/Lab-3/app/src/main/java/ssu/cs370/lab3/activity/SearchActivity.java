package ssu.cs370.lab3.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import ssu.cs370.lab3.R;
import ssu.cs370.lab3.model.RecipeModel;
import ssu.cs370.lab3.service.IRecipeCallbackListener;
import ssu.cs370.lab3.service.RecipeSearchAsyncTask;

public class SearchActivity extends AppCompatActivity {

    private EditText searchEditText;
    private Button searchButton;
    private TextView recipeName;
    private TextView recipeDescription;
    private ImageView recipeThumbnail;
    IRecipeCallbackListener recipeCallbackListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
    }
}
