package ssu.cs370.lab3.service;

import ssu.cs370.lab3.model.RecipeModel;

public interface IRecipeCallbackListener {
    void onRecipeCallback(RecipeModel recipeModel);
}
