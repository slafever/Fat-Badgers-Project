package ssu.cs370.lab3.service;

import android.os.AsyncTask;

import java.io.IOException;

import ssu.cs370.lab3.model.RecipeModel;
import ssu.cs370.lab3.utility.RecipeParser;
import ssu.cs370.lab3.utility.UrlFormatUtility;

public class RecipeSearchAsyncTask extends AsyncTask<String, String, RecipeModel> {
    private IRecipeCallbackListener recipeCallbackListener;

    @Override
    protected RecipeModel doInBackground(String... params) {
        return null;
    }

    @Override
    protected void onPostExecute(RecipeModel recipeModel) {
        super.onPostExecute(recipeModel);
    }

    public void setRecipeCallbackListener(IRecipeCallbackListener recipeCallbackListener) {
        this.recipeCallbackListener = recipeCallbackListener;
    }
}
