package ssu.cs370.lab3.utility;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import ssu.cs370.lab3.model.RecipeModel;

public class RecipeParser {
    public static final RecipeModel parseRecipeFromJson(final String inputString) {
        RecipeModel recipeModel = new RecipeModel();

        try {
            // Convert the String to a JSONObject for Java
            JSONObject json = new JSONObject(inputString);
            // Get the array of matches from the JSONObject
            JSONArray matchArray = json.getJSONArray("matches");
            // Get the first recipe from the Array
            JSONObject recipeJson = matchArray.getJSONObject(0);
            // set the recipe name on the recipe model
            recipeModel.setRecipeName(recipeJson.getString("recipeName"));
        } catch (JSONException exception) {
            // log something
        }

        return recipeModel;
    }
}
