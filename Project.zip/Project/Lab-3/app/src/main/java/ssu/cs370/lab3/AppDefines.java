package ssu.cs370.lab3;

public class AppDefines {
    public static final String APPLICATION_ID = "4911b643";
    public static final String APPLICATION_KEY = "ec3e34e0bb6801670dbd3dbd02ce7608";
    public static final String BASE_API_URL = "https://api.yummly.com/v1/api";
}
